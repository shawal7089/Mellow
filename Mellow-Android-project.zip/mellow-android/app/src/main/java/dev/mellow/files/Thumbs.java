package dev.mellow.files;

import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.util.Size;

import java.io.File;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Image / video thumbnails: two background threads, skipped for rows that scrolled away. */
final class Thumbs {
    private Thumbs() {}

    static final int PX = 256;

    interface Cb {
        boolean wanted(String key);
        void got(String key, Bitmap b);
    }

    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(
            (int) Math.max(4L * 1024 * 1024, Runtime.getRuntime().maxMemory() / 8)) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };
    private static final Set<String> PENDING = Collections.synchronizedSet(new HashSet<String>());
    private static final Set<String> FAILED = Collections.synchronizedSet(new HashSet<String>());
    private static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static Bitmap peek(String key) { return CACHE.get(key); }

    static void load(final File f, final int kind, final String key, final Cb cb) {
        if (FAILED.contains(key) || !PENDING.add(key)) return;
        POOL.execute(new Runnable() {
            @Override public void run() {
                Bitmap b = null;
                try {
                    if (cb.wanted(key)) {
                        Size sz = new Size(PX, PX);
                        b = kind == 1 ? ThumbnailUtils.createVideoThumbnail(f, sz, null) : ThumbnailUtils.createImageThumbnail(f, sz, null);
                    }
                } catch (Throwable ignored) {
                    b = null;
                }
                PENDING.remove(key);
                if (b == null) {
                    if (cb.wanted(key)) FAILED.add(key);
                    return;
                }
                CACHE.put(key, b);
                final Bitmap fb = b;
                MAIN.post(new Runnable() {
                    @Override public void run() { cb.got(key, fb); }
                });
            }
        });
    }
}

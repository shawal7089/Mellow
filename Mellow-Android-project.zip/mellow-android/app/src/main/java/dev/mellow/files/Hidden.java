package dev.mellow.files;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Systemwide hiding: the item gets a leading dot (every Android app, gallery and file picker hides
 * dot-items), and a small registry remembers the original name so it can be put back.
 */
public final class Hidden {
    private final File registry;

    public Hidden(File registry) { this.registry = registry; }

    public Map<String, String> load() {
        Map<String, String> m = new LinkedHashMap<>();
        try {
            if (!registry.isFile()) return m;
            for (String line : Files.readAllLines(registry.toPath(), StandardCharsets.UTF_8)) {
                int tab = line.indexOf('\t');
                if (tab <= 0) continue;
                m.put(Trash.unesc(line.substring(0, tab)), Trash.unesc(line.substring(tab + 1)));
            }
        } catch (IOException ignored) { }
        return m;
    }

    private void save(Map<String, String> m) throws IOException {
        File dir = registry.getParentFile();
        if (dir != null && !dir.isDirectory() && !dir.mkdirs()) throw new IOException("cannot create " + dir.getPath());
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : m.entrySet()) {
            sb.append(Trash.esc(e.getKey())).append('\t').append(Trash.esc(e.getValue())).append('\n');
        }
        File tmp = new File(registry.getPath() + ".tmp");
        Files.write(tmp.toPath(), sb.toString().getBytes(StandardCharsets.UTF_8));
        Files.move(tmp.toPath(), registry.toPath(), StandardCopyOption.REPLACE_EXISTING);
    }

    public FileOps.Result hide(List<File> files) {
        FileOps.Result r = new FileOps.Result();
        Map<String, String> reg = load();
        for (File f : files) {
            String name = f.getName();
            try {
                if (name.startsWith(".")) throw new IOException("already hidden (name starts with a dot)");
                File to = FileOps.uniquePath(f.getParentFile(), "." + name);
                if (!f.renameTo(to)) throw new IOException("could not rename");
                reg.put(to.getAbsolutePath(), f.getAbsolutePath());
                r.ok++;
            } catch (Exception e) {
                r.errors.add(name + ": " + e.getMessage());
            }
        }
        try { save(reg); } catch (IOException e) { r.errors.add("could not save the hidden list: " + e.getMessage()); }
        return r;
    }

    public FileOps.Result unhide(List<File> files) {
        FileOps.Result r = new FileOps.Result();
        Map<String, String> reg = load();
        for (File h : files) {
            String hp = h.getAbsolutePath();
            try {
                String orig = reg.get(hp);
                File folder = h.getParentFile();
                String base = h.getName();
                if (orig != null) {
                    File of = new File(orig);
                    if (of.getParentFile() != null && of.getParentFile().isDirectory()) folder = of.getParentFile();
                    base = of.getName();
                } else if (base.startsWith(".")) {
                    base = base.substring(1);
                }
                if (base.isEmpty()) throw new IOException("cannot work out the original name");
                File to = FileOps.uniquePath(folder, base);
                if (!h.renameTo(to)) throw new IOException("could not rename");
                reg.remove(hp);
                r.ok++;
            } catch (Exception e) {
                r.errors.add(h.getName() + ": " + e.getMessage());
            }
        }
        try { save(reg); } catch (IOException e) { r.errors.add("could not save the hidden list: " + e.getMessage()); }
        return r;
    }

    /** Everything hidden with Mellow, shown under its original name. */
    public List<Entry> items() {
        Map<String, String> reg = load();
        List<Entry> out = new ArrayList<>();
        java.util.Set<String> used = new java.util.HashSet<>();
        boolean changed = false;
        for (Map.Entry<String, String> e : new ArrayList<>(reg.entrySet())) {
            File h = new File(e.getKey());
            if (!FileOps.exists(h)) {
                File parent = h.getParentFile();
                if (parent != null && parent.isDirectory()) { reg.remove(e.getKey()); changed = true; }
                continue; // parent folder missing: its drive may just be unplugged, keep the record
            }
            String name = new File(e.getValue()).getName();
            if (name.isEmpty()) name = h.getName().replaceFirst("^\\.", "");
            String shown = name;
            for (int i = 2; used.contains(shown); i++) shown = name + " (" + i + ")";
            used.add(shown);
            Entry en = FileOps.entryFor(h, shown);
            if (en != null) out.add(en);
        }
        if (changed) { try { save(reg); } catch (IOException ignored) { } }
        return out;
    }
}

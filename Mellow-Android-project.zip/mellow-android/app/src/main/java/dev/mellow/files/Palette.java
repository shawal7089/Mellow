package dev.mellow.files;

/** Colours and themes. Pure Java (no Android imports) so it can be tested anywhere. */
public final class Palette {
    private Palette() {}

    public static final int WHITE = 0xFFFFFFFF, BLACK = 0xFF000000;
    public static final String[] NAMES = {"Dusk", "Rose", "Sage", "Ocean", "Sand", "Mocha", "Cotton"};
    // bg1, bg2, accent1, accent2, text, muted
    private static final int[][] SETS = {
        {0x17181f, 0x1d1e29, 0x8f9be0, 0xa98fd9, 0xe4e6ee, 0x8b8fa3},
        {0x1b1719, 0x231c21, 0xd6a0ae, 0xc99ac0, 0xece4e7, 0x9d8e94},
        {0x151917, 0x1b211e, 0x93bfa6, 0xa6c4a0, 0xe3ebe6, 0x869a8f},
        {0x14191f, 0x1a212b, 0x8fb4d9, 0x8fa6e0, 0xe2e9f1, 0x8796a8},
        {0x1b1916, 0x221f1b, 0xd9b98c, 0xd4a98f, 0xece6dd, 0xa09886},
        {0x1e1e2e, 0x242438, 0xb8a1e0, 0xd3aed0, 0xcdd6f4, 0x9399b2},
        {0xf4f3f7, 0xeae9f1, 0x8a86d6, 0xa98ad0, 0x2c2b3a, 0x7a7890},
    };
    private static final boolean[] DARK = {true, true, true, true, true, true, false};
    /** Colour intensity: Soft, Balanced, Vivid. */
    public static final float[] VIBE = {0.6f, 1.0f, 1.5f};

    // file kinds: 0 image 1 video 2 audio 3 archive 4 doc 5 sheet 6 slides 7 code 8 app 9 other
    public static final int[] KIND_C1 = {0xFF7fcfb3, 0xFFe59ab8, 0xFFaaa0e0, 0xFFe6c27a, 0xFF85aee0, 0xFFb5d98a, 0xFFe8a77a, 0xFF86d09c, 0xFFd4a5d8, 0xFFa3adbb};
    public static final int[] KIND_C2 = {0xFF6cbcc9, 0xFFd9858a, 0xFF8d93d6, 0xFFdc9a6c, 0xFF7192d6, 0xFF7cc596, 0xFFd98a80, 0xFF70b0d6, 0xFFb98acb, 0xFF8a96a8};

    public static final class Theme {
        public final String name;
        public final boolean dark;
        public final float k;
        public final int bg1, bg2, a1, a2, text, muted;

        Theme(String name, boolean dark, int[] c, float k) {
            this.name = name; this.dark = dark; this.k = k;
            bg1 = 0xFF000000 | c[0]; bg2 = 0xFF000000 | c[1];
            a1 = 0xFF000000 | c[2]; a2 = 0xFF000000 | c[3];
            text = 0xFF000000 | c[4]; muted = 0xFF000000 | c[5];
        }

        /** Alpha scaled by the colour intensity. */
        public int ga(int a) { return Math.min(255, Math.round(a * k)); }
        public int panelTop() { return dark ? alpha(mix(WHITE, a1, 0.45f), ga(26)) : alpha(mix(WHITE, a1, 0.10f * k), 185); }
        public int panelBottom() { return dark ? alpha(mix(WHITE, a2, 0.45f), ga(10)) : alpha(mix(WHITE, a2, 0.10f * k), 130); }
        public int panelBorder() { return alpha(a1, ga(48)); }
        public int hover() { return dark ? alpha(WHITE, 18) : alpha(BLACK, 16); }
        public int field() { return dark ? alpha(WHITE, 14) : alpha(WHITE, 190); }
        public int barFill() { return dark ? mix(bg2, WHITE, 0.10f) : WHITE; }
    }

    public static Theme named(String name, float k) {
        for (int i = 0; i < NAMES.length; i++) {
            if (NAMES[i].equals(name)) return new Theme(NAMES[i], DARK[i], SETS[i], k);
        }
        return new Theme(NAMES[0], DARK[0], SETS[0], k);
    }

    /** A whole theme built from one accent colour. */
    public static Theme custom(int accentRgb, boolean dark, float k) {
        float[] hsl = toHsl(accentRgb);
        float h = hsl[0];
        float s = Math.max(hsl[1], 0.25f);
        float l = hsl[2];
        int a1 = hsl(h, s, l);
        int a2 = hsl(h + 0.08f, s, l);
        int[] c;
        if (dark) {
            c = new int[]{hsl(h, 0.20f, 0.09f), hsl(h + 0.02f, 0.24f, 0.13f), a1, a2, hsl(h, 0.18f, 0.92f), hsl(h, 0.10f, 0.62f)};
        } else {
            c = new int[]{hsl(h, 0.35f, 0.96f), hsl(h + 0.02f, 0.35f, 0.92f), a1, a2, hsl(h, 0.25f, 0.17f), hsl(h, 0.12f, 0.48f)};
        }
        for (int i = 0; i < c.length; i++) c[i] &= 0xFFFFFF;
        return new Theme("Custom", dark, c, k);
    }

    public static int alpha(int rgb, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF);
    }

    public static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }

    public static int hsl(float h, float s, float l) {
        h = h - (float) Math.floor(h);
        s = clamp01(s);
        l = clamp01(l);
        float c = (1f - Math.abs(2f * l - 1f)) * s;
        float hp = h * 6f;
        float x = c * (1f - Math.abs(hp % 2f - 1f));
        float r = 0, g = 0, b = 0;
        if (hp < 1) { r = c; g = x; }
        else if (hp < 2) { r = x; g = c; }
        else if (hp < 3) { g = c; b = x; }
        else if (hp < 4) { g = x; b = c; }
        else if (hp < 5) { r = x; b = c; }
        else { r = c; b = x; }
        float m = l - c / 2f;
        int ri = Math.round((r + m) * 255f), gi = Math.round((g + m) * 255f), bi = Math.round((b + m) * 255f);
        return 0xFF000000 | (ri << 16) | (gi << 8) | bi;
    }

    public static float[] toHsl(int rgb) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        float l = (max + min) / 2f, h = 0, s = 0;
        if (max != min) {
            float d = max - min;
            s = l > 0.5f ? d / (2f - max - min) : d / (max + min);
            if (max == r) h = (g - b) / d + (g < b ? 6f : 0f);
            else if (max == g) h = (b - r) / d + 2f;
            else h = (r - g) / d + 4f;
            h /= 6f;
        }
        return new float[]{h, s, l};
    }
}

package dev.mellow.files;

import java.io.File;

/** One row in a folder listing. */
public final class Entry {
    public final File file;
    public final String name;   // name shown to the user (can differ from file.getName() in Trash / Hidden)
    public final boolean dir;
    public final long size;
    public final long mtime;
    public final int kind;      // -1 for folders, otherwise 0..9 (see Palette)

    public Entry(File file, String name, boolean dir, long size, long mtime) {
        this.file = file;
        this.name = name;
        this.dir = dir;
        this.size = size;
        this.mtime = mtime;
        this.kind = dir ? -1 : FileOps.kindOf(name);
    }

    public String path() { return file.getPath(); }
}

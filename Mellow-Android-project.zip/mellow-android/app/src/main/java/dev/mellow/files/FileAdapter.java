package dev.mellow.files;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Feeds ItemViews to the grid or the list. */
final class FileAdapter extends BaseAdapter {
    private final Context ctx;
    private final Set<String> selected;
    private final boolean list;
    private final int iconPx;
    private List<Entry> items = new ArrayList<>();
    boolean selMode;

    FileAdapter(Context ctx, Set<String> selected, boolean list, int iconPx) {
        this.ctx = ctx;
        this.selected = selected;
        this.list = list;
        this.iconPx = iconPx;
    }

    void setItems(List<Entry> l) {
        items = l;
        notifyDataSetChanged();
    }

    int cellHeight() { return list ? Ui.dp(64) : iconPx + Ui.dp(58); }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int i) { return items.get(i); }
    @Override public long getItemId(int i) { return i; }

    @Override public View getView(int pos, View convert, ViewGroup parent) {
        ItemView v = convert instanceof ItemView ? (ItemView) convert : new ItemView(ctx);
        v.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, cellHeight()));
        Entry e = items.get(pos);
        v.bind(e, selected.contains(e.path()), selMode, list, iconPx);
        return v;
    }
}

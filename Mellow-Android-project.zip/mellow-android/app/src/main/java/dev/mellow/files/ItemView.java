package dev.mellow.files;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;

import java.text.DateFormat;
import java.util.Date;

/** One tile (grid) or one row (list). Everything is painted by hand, like the desktop app. */
final class ItemView extends View {
    private Entry e;
    private boolean sel, selMode, list;
    private int iconPx;
    private Bitmap thumb;
    private String key;
    private StaticLayout nameLayout, subLayout;
    private final TextPaint namePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint subPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private static final DateFormat DATE = DateFormat.getDateInstance(DateFormat.MEDIUM);

    private final Thumbs.Cb cb = new Thumbs.Cb() {
        @Override public boolean wanted(String k) { return k.equals(key); }
        @Override public void got(String k, Bitmap b) {
            if (k.equals(key)) { thumb = b; invalidate(); }
        }
    };

    ItemView(Context c) { super(c); }

    void bind(Entry entry, boolean selected, boolean selectionMode, boolean asList, int iconSize) {
        e = entry; sel = selected; selMode = selectionMode; list = asList; iconPx = iconSize;
        thumb = null;
        key = null;
        if (!e.dir && (e.kind == 0 || e.kind == 1)) {
            key = e.path() + "|" + e.mtime + "|" + e.size;
            thumb = Thumbs.peek(key);
            if (thumb == null) Thumbs.load(e.file, e.kind, key, cb);
        }
        buildLayouts(getWidth());
        invalidate();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        buildLayouts(w);
    }

    private void buildLayouts(int w) {
        if (e == null || w <= 0) return;
        Palette.Theme t = Ui.t;
        namePaint.setTextSize(Ui.sp(list ? 14.5f : 12f));
        namePaint.setColor(t.text);
        subPaint.setTextSize(Ui.sp(11.5f));
        subPaint.setColor(t.muted);
        int textW = list ? w - Ui.dp(14 + 40 + 12 + 14) : w - Ui.dp(14);
        textW = Math.max(1, textW);
        nameLayout = StaticLayout.Builder.obtain(e.name, 0, e.name.length(), namePaint, textW)
                .setMaxLines(list ? 1 : 2)
                .setEllipsize(list ? TextUtils.TruncateAt.MIDDLE : TextUtils.TruncateAt.END)
                .setAlignment(list ? Layout.Alignment.ALIGN_NORMAL : Layout.Alignment.ALIGN_CENTER)
                .build();
        subLayout = null;
        if (list) {
            String when = DATE.format(new Date(e.mtime));
            String sub = e.dir ? when : FileOps.humanSize(e.size) + "  ·  " + when;
            subLayout = StaticLayout.Builder.obtain(sub, 0, sub.length(), subPaint, textW)
                    .setMaxLines(1).setEllipsize(TextUtils.TruncateAt.END).build();
        }
    }

    @Override public void setPressed(boolean pressed) {
        super.setPressed(pressed);
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        if (e == null) return;
        Palette.Theme t = Ui.t;
        float w = getWidth(), h = getHeight();
        float m = Ui.dp(3);
        r.set(m, m, w - m, h - m);
        float rad = Ui.dp(14);
        if (sel) {
            p.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
                    Palette.alpha(t.a1, t.ga(85)), Palette.alpha(t.a2, t.ga(65)), Shader.TileMode.CLAMP));
            p.setStyle(Paint.Style.FILL);
            c.drawRoundRect(r, rad, rad, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f, Ui.dp(1)));
            p.setColor(Palette.alpha(t.a1, t.ga(120)));
            c.drawRoundRect(r, rad, rad, p);
            p.setStyle(Paint.Style.FILL);
        } else if (isPressed()) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(t.hover());
            c.drawRoundRect(r, rad, rad, p);
        }
        if (list) {
            float s = Ui.dp(40);
            float ix = Ui.dp(14), iy = (h - s) / 2f;
            drawIcon(c, ix, iy, s, t);
            float tx = ix + s + Ui.dp(12);
            float blockH = nameLayout.getHeight() + (subLayout != null ? subLayout.getHeight() : 0);
            float ty = (h - blockH) / 2f;
            c.save();
            c.translate(tx, ty);
            nameLayout.draw(c);
            c.translate(0, nameLayout.getHeight());
            if (subLayout != null) subLayout.draw(c);
            c.restore();
            if (selMode) drawCheck(c, w - Ui.dp(26), h / 2f, t);
        } else {
            float s = iconPx;
            float ix = (w - s) / 2f, iy = Ui.dp(8);
            drawIcon(c, ix, iy, s, t);
            c.save();
            c.translate(Ui.dp(7), iy + s + Ui.dp(6));
            nameLayout.draw(c);
            c.restore();
            if (selMode) drawCheck(c, Ui.dp(18), Ui.dp(18), t);
        }
    }

    private void drawIcon(Canvas c, float x, float y, float s, Palette.Theme t) {
        if (e.dir) Icons.folder(c, x, y, s, s, t);
        else Icons.file(c, x, y, s, s, e.kind, FileOps.ext(e.name), thumb, t);
    }

    private void drawCheck(Canvas c, float cx, float cy, Palette.Theme t) {
        float rr = Ui.dp(10);
        if (sel) {
            p.setShader(new LinearGradient(cx - rr, cy - rr, cx + rr, cy + rr, t.a1, t.a2, Shader.TileMode.CLAMP));
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(cx, cy, rr, p);
            p.setShader(null);
            Glyphs.draw(c, "check", cx, cy, rr * 1.5f, t.dark ? 0xFF1b1d2a : 0xFFFFFFFF);
        } else {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1.5f, Ui.dp(1.5f)));
            p.setColor(Palette.alpha(t.text, 130));
            c.drawCircle(cx, cy, rr, p);
            p.setStyle(Paint.Style.FILL);
        }
    }
}

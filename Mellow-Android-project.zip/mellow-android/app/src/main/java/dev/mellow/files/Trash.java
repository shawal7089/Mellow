package dev.mellow.files;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/**
 * Trash that lives on each storage volume: <volume>/.Mellow/trash/files + .../info
 * (Android has no trash of its own). Moving to trash is a rename, so it is instant.
 */
public final class Trash {
    private Trash() {}

    /** Which storage volume a path lives on (longest matching root), or null. */
    public static File volumeOf(File f, List<File> roots) {
        String p = f.getAbsolutePath();
        File best = null;
        for (File r : roots) {
            String rp = r.getAbsolutePath();
            if (p.equals(rp) || p.startsWith(rp.endsWith("/") ? rp : rp + "/")) {
                if (best == null || rp.length() > best.getAbsolutePath().length()) best = r;
            }
        }
        return best;
    }

    private static File filesDir(File vol) { return new File(vol, ".Mellow/trash/files"); }
    private static File infoDir(File vol) { return new File(vol, ".Mellow/trash/info"); }

    private static File infoFor(File stored) {
        File filesDir = stored.getParentFile();
        File trashDir = filesDir == null ? null : filesDir.getParentFile();
        if (trashDir == null) return null;
        return new File(new File(trashDir, "info"), stored.getName() + ".tsv");
    }

    public static File moveToTrash(File f, List<File> roots) throws IOException {
        File vol = volumeOf(f, roots);
        if (vol == null) throw new IOException("not on a known storage volume");
        if (f.getAbsolutePath().contains("/.Mellow/")) throw new IOException("Mellow's own folder can't be trashed");
        File fd = filesDir(vol), idir = infoDir(vol);
        if (!fd.isDirectory() && !fd.mkdirs()) throw new IOException("cannot create the trash folder");
        if (!idir.isDirectory() && !idir.mkdirs()) throw new IOException("cannot create the trash folder");
        try { new File(vol, ".Mellow/.nomedia").createNewFile(); } catch (IOException ignored) { }
        File stored = FileOps.uniquePath(fd, f.getName());
        File info = new File(idir, stored.getName() + ".tsv");
        String rec = esc(f.getAbsolutePath()) + "\n" + System.currentTimeMillis() + "\n";
        Files.write(info.toPath(), rec.getBytes(StandardCharsets.UTF_8));
        if (!f.renameTo(stored)) {
            info.delete();
            throw new IOException("could not move " + f.getName() + " to the trash");
        }
        return stored;
    }

    public static List<Entry> list(List<File> roots) {
        List<Entry> out = new ArrayList<>();
        for (File vol : roots) {
            File[] kids = filesDir(vol).listFiles();
            if (kids == null) continue;
            for (File k : kids) {
                String name = k.getName();
                long when = k.lastModified();
                String[] rec = readInfo(k);
                if (rec != null) {
                    String orig = new File(rec[0]).getName();
                    if (!orig.isEmpty()) name = orig;
                    try { when = Long.parseLong(rec[1]); } catch (NumberFormatException ignored) { }
                }
                Entry e = FileOps.entryFor(k, name);
                if (e != null) out.add(new Entry(k, name, e.dir, e.size, when));
            }
        }
        return out;
    }

    private static String[] readInfo(File stored) {
        File info = infoFor(stored);
        if (info == null || !info.isFile()) return null;
        try {
            List<String> lines = Files.readAllLines(info.toPath(), StandardCharsets.UTF_8);
            if (lines.size() < 2) return null;
            return new String[]{unesc(lines.get(0)), lines.get(1).trim()};
        } catch (IOException e) {
            return null;
        }
    }

    /** Puts a trashed item back where it came from. Returns the new location. */
    public static File restore(File stored) throws IOException {
        String[] rec = readInfo(stored);
        File target;
        if (rec != null) {
            File orig = new File(rec[0]);
            File folder = orig.getParentFile();
            if (folder == null) throw new IOException("original location unknown");
            if (!folder.isDirectory() && !folder.mkdirs()) throw new IOException("cannot recreate " + folder.getPath());
            target = folder;
            File dst = FileOps.moveItemAs(stored, FileOps.uniquePath(folder, orig.getName()));
            deleteInfo(stored);
            return dst;
        }
        // no record: put it in <volume>/Restored
        File vol = stored.getParentFile().getParentFile().getParentFile().getParentFile();
        target = new File(vol, "Restored");
        if (!target.isDirectory() && !target.mkdirs()) throw new IOException("cannot create " + target.getPath());
        File dst = FileOps.moveItem(stored, target, null);
        deleteInfo(stored);
        return dst;
    }

    private static void deleteInfo(File stored) {
        File info = infoFor(stored);
        if (info != null) info.delete();
    }

    public static boolean purge(File stored) {
        boolean ok = FileOps.deleteRecursive(stored);
        deleteInfo(stored);
        return ok;
    }

    public static int emptyAll(List<File> roots) {
        int n = 0;
        for (File vol : roots) {
            File[] kids = filesDir(vol).listFiles();
            if (kids == null) continue;
            for (File k : kids) { if (purge(k)) n++; }
            File[] infos = infoDir(vol).listFiles();
            if (infos != null) for (File i : infos) i.delete();
        }
        return n;
    }

    static String esc(String s) { return s.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n"); }

    static String unesc(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char d = s.charAt(++i);
                sb.append(d == 't' ? '\t' : d == 'n' ? '\n' : d);
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}

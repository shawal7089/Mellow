package dev.mellow.files;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

/** The folder and file pictures (same drawing as the desktop Mellow). */
final class Icons {
    private Icons() {}

    private static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint BMP = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private static final Paint TXT = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final RectF R = new RectF();
    private static final Rect SRC = new Rect();
    private static final Path PATH = new Path();

    static void folder(Canvas c, float x0, float y0, float w, float h, Palette.Theme t) {
        float fw = w * 0.90f, fh = fw * 0.76f;
        float x = x0 + (w - fw) / 2f, y = y0 + (h - fh) / 2f;
        int base = Palette.mix(Palette.mix(t.a1, t.a2, 0.45f), 0xFF9AA0B0, Math.max(0f, 0.20f - 0.10f * t.k));
        base = Palette.mix(base, Palette.WHITE, 0.06f);
        int back = Palette.mix(base, Palette.BLACK, 0.20f);
        int top = Palette.mix(base, Palette.WHITE, 0.14f);
        float rad = fw * 0.13f;
        P.setStyle(Paint.Style.FILL);
        P.setShader(null);
        P.setColor(back);
        R.set(x, y, x + fw * 0.42f, y + fh * 0.34f);
        c.drawRoundRect(R, rad * 0.8f, rad * 0.8f, P);
        R.set(x, y + fh * 0.12f, x + fw, y + fh);
        c.drawRoundRect(R, rad, rad, P);
        R.set(x, y + fh * 0.30f, x + fw, y + fh);
        P.setShader(new LinearGradient(0, R.top, 0, R.bottom, top, base, Shader.TileMode.CLAMP));
        c.drawRoundRect(R, rad, rad, P);
        P.setShader(null);
    }

    static void file(Canvas c, float x0, float y0, float w, float h, int kind, String ext, Bitmap thumb, Palette.Theme t) {
        if (kind < 0 || kind > 9) kind = 9;
        int c1 = Palette.KIND_C1[kind], c2 = Palette.KIND_C2[kind];
        if (thumb != null) {
            float bx = x0 + w * 0.04f, by = y0 + h * 0.04f, bw = w * 0.92f, bh = h * 0.92f, rad = w * 0.12f;
            R.set(bx, by, bx + bw, by + bh);
            PATH.reset();
            PATH.addRoundRect(R, rad, rad, Path.Direction.CW);
            c.save();
            c.clipPath(PATH);
            int tw = thumb.getWidth(), th = thumb.getHeight();
            float sc = Math.max(bw / tw, bh / th);
            float sw = bw / sc, sh = bh / sc;
            SRC.set((int) ((tw - sw) / 2f), (int) ((th - sh) / 2f), (int) ((tw + sw) / 2f), (int) ((th + sh) / 2f));
            c.drawBitmap(thumb, SRC, R, BMP);
            c.restore();
            P.setStyle(Paint.Style.STROKE);
            P.setStrokeWidth(Math.max(1f, Ui.dp(1)));
            P.setColor(Palette.alpha(0xFFFFFF, 50));
            c.drawRoundRect(R, rad, rad, P);
            P.setStyle(Paint.Style.FILL);
            return;
        }
        float px = x0 + w * 0.17f, py = y0 + h * 0.05f, pw = w * 0.66f, ph = h * 0.90f, rad = w * 0.09f;
        int top = t.dark ? 0xFFF3F4F8 : 0xFFFFFFFF;
        int bot = t.dark ? 0xFFD9DBE4 : 0xFFE8E9F0;
        R.set(px, py, px + pw, py + ph);
        P.setStyle(Paint.Style.FILL);
        P.setShader(new LinearGradient(0, py, 0, py + ph, Palette.mix(top, c1, 0.10f * t.k), Palette.mix(bot, c2, 0.22f * t.k), Shader.TileMode.CLAMP));
        c.drawRoundRect(R, rad, rad, P);
        P.setShader(null);
        if (!t.dark) {
            P.setStyle(Paint.Style.STROKE);
            P.setStrokeWidth(Math.max(1f, Ui.dp(1)));
            P.setColor(Palette.alpha(0x000000, 28));
            c.drawRoundRect(R, rad, rad, P);
            P.setStyle(Paint.Style.FILL);
        }
        float fs = w * 0.20f, fx = px + pw - fs, fy = py;
        PATH.reset();
        PATH.moveTo(fx, fy);
        PATH.lineTo(fx + fs, fy + fs);
        PATH.lineTo(fx, fy + fs);
        PATH.close();
        P.setColor(Palette.alpha(0x000000, 30));
        c.drawPath(PATH, P);
        boolean hasExt = ext != null && !ext.isEmpty();
        float[] rows = hasExt ? new float[]{0.30f, 0.40f} : new float[]{0.40f, 0.50f, 0.60f, 0.70f};
        float lh = Math.max(1f, h * 0.028f), lx = px + pw * 0.16f, lw = pw * 0.68f;
        P.setColor(Palette.alpha(0x5b6075, 60));
        for (int i = 0; i < rows.length; i++) {
            float ww = i == rows.length - 1 ? lw * 0.7f : lw;
            R.set(lx, y0 + h * rows[i], lx + ww, y0 + h * rows[i] + lh);
            c.drawRoundRect(R, lh / 2f, lh / 2f, P);
        }
        if (hasExt) {
            String label = ext.toUpperCase(java.util.Locale.ROOT);
            if (label.length() > 4) label = label.substring(0, 4);
            float bh = ph * 0.24f, bw = pw * 0.78f;
            float cx = px + pw / 2f, cy = y0 + h * 0.68f;
            R.set(cx - bw / 2f, cy - bh / 2f, cx + bw / 2f, cy + bh / 2f);
            P.setShader(new LinearGradient(R.left, 0, R.right, 0, c1, c2, Shader.TileMode.CLAMP));
            c.drawRoundRect(R, bh * 0.42f, bh * 0.42f, P);
            P.setShader(null);
            TXT.setTypeface(Typeface.DEFAULT_BOLD);
            float px2 = Math.max(5f, bh * 0.62f);
            TXT.setTextSize(px2);
            while (TXT.measureText(label) > bw * 0.84f && px2 > 4f) {
                px2 -= 1f;
                TXT.setTextSize(px2);
            }
            TXT.setColor(0xE11F2233);
            TXT.setTextAlign(Paint.Align.CENTER);
            Paint.FontMetrics fm = TXT.getFontMetrics();
            c.drawText(label, cx, cy - (fm.ascent + fm.descent) / 2f, TXT);
        }
    }
}

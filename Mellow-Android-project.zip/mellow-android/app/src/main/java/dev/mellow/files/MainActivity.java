package dev.mellow.files;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int M_DIR = 0, M_TRASH = 1, M_HIDDEN = 2;

    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService lister = Executors.newSingleThreadExecutor();
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    // storage
    private final List<File> roots = new ArrayList<>();
    private final List<String> rootNames = new ArrayList<>();
    private File primary;
    private Hidden hiddenStore;
    private boolean started;

    // state
    private int mode = M_DIR;
    private File cwd, lastDir;
    private List<Entry> all = new ArrayList<>();
    private List<Entry> shown = new ArrayList<>();
    private String query = "";
    private final LinkedHashSet<String> selected = new LinkedHashSet<>();
    private final List<File> clip = new ArrayList<>();
    private boolean clipCut;
    private int version;
    private boolean loadError, scrollTop;

    // settings
    private int sortKey, zoomDp;
    private boolean sortDesc, asList, showDot;

    // views
    private FrameLayout root, listHost;
    private LinearLayout column, crumbs, chips, selBar, pasteBar;
    private HorizontalScrollView crumbScroll;
    private IconButton upBtn, searchBtn, viewBtn, moreBtn;
    private EditText searchBox;
    private TextView emptyText, statusText, pasteText;
    private AbsListView listWidget;
    private GridView gridView;
    private FileAdapter adapter;
    private View permView;

    private interface TextCb { void got(String s); }

    // ---- lifecycle -----------------------------------------------------------------------
    @Override protected void onCreate(Bundle b) {
        prefs = getSharedPreferences("mellow", MODE_PRIVATE);
        Ui.init(this);
        loadPrefs();
        setTheme(Ui.t.dark ? R.style.AppDark : R.style.AppLight);
        super.onCreate(b);
        buildUi();
        if (!hasAccess()) showPermission();
    }

    @Override protected void onResume() {
        super.onResume();
        if (!started) {
            if (hasAccess()) {
                if (permView != null) { root.removeView(permView); permView = null; }
                column.setVisibility(View.VISIBLE);
                start();
            }
        } else {
            loadVolumes();
            rebuildChips();
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        lister.shutdownNow();
        worker.shutdown();
    }

    @Override public void onBackPressed() {
        if (!selected.isEmpty()) { clearSelection(); return; }
        if (searchBox != null && searchBox.getVisibility() == View.VISIBLE) { closeSearch(); return; }
        if (started && canGoUp()) { goUp(); return; }
        super.onBackPressed();
    }

    private boolean hasAccess() { return Environment.isExternalStorageManager(); }

    private void loadPrefs() {
        sortKey = prefs.getInt("sortKey", FileOps.SORT_NAME);
        sortDesc = prefs.getBoolean("sortDesc", false);
        asList = prefs.getBoolean("asList", false);
        zoomDp = prefs.getInt("zoomDp", 56);
        showDot = prefs.getBoolean("showDot", false);
        int vibe = Math.max(0, Math.min(2, prefs.getInt("vibe", 1)));
        float k = Palette.VIBE[vibe];
        String name = prefs.getString("palette", "Dusk");
        if ("Custom".equals(name)) {
            Ui.t = Palette.custom(prefs.getInt("customAccent", 0xFF8f9be0), prefs.getBoolean("customDark", true), k);
        } else {
            Ui.t = Palette.named(name, k);
        }
    }

    private void start() {
        started = true;
        loadVolumes();
        hiddenStore = new Hidden(new File(primary, ".Mellow/hidden.tsv"));
        File last = new File(prefs.getString("last", primary.getAbsolutePath()));
        File open = (last.isDirectory() && Trash.volumeOf(last, roots) != null) ? last : primary;
        setupList();
        openDir(open);
    }

    private void loadVolumes() {
        roots.clear();
        rootNames.clear();
        primary = null;
        StorageManager sm = (StorageManager) getSystemService(Context.STORAGE_SERVICE);
        for (StorageVolume v : sm.getStorageVolumes()) {
            File d = v.getDirectory();
            if (d == null || !Environment.MEDIA_MOUNTED.equals(v.getState())) continue;
            roots.add(d);
            rootNames.add(v.isPrimary() ? "Internal storage" : String.valueOf(v.getDescription(this)));
            if (v.isPrimary()) primary = d;
        }
        if (primary == null) {
            primary = Environment.getExternalStorageDirectory();
            if (!roots.contains(primary)) { roots.add(0, primary); rootNames.add(0, "Internal storage"); }
        }
    }

    // ---- building the screen ---------------------------------------------------------------
    private TextView label(String s, float sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    private IconButton iconBtn(String kind, View.OnClickListener l) {
        IconButton b = new IconButton(this, kind);
        b.setOnClickListener(l);
        return b;
    }

    private void buildUi() {
        final Palette.Theme t = Ui.t;
        root = new FrameLayout(this);
        root.setBackground(new Ui.GradientBg());
        column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(12), Ui.dp(8));
        root.addView(column, new FrameLayout.LayoutParams(MATCH, MATCH));

        // top bar: up | path | search | view | more
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        upBtn = iconBtn("up", v -> goUp());
        top.addView(upBtn);
        FrameLayout crumbPanel = new FrameLayout(this);
        crumbPanel.setBackground(Ui.panel(16));
        crumbScroll = new HorizontalScrollView(this);
        crumbScroll.setHorizontalScrollBarEnabled(false);
        crumbs = new LinearLayout(this);
        crumbs.setGravity(Gravity.CENTER_VERTICAL);
        crumbs.setPadding(Ui.dp(6), 0, Ui.dp(6), 0);
        crumbScroll.addView(crumbs, new FrameLayout.LayoutParams(WRAP, MATCH));
        crumbPanel.addView(crumbScroll, new FrameLayout.LayoutParams(MATCH, MATCH));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, Ui.dp(44), 1f);
        cp.setMargins(Ui.dp(4), 0, Ui.dp(4), 0);
        top.addView(crumbPanel, cp);
        searchBtn = iconBtn("search", v -> toggleSearch());
        viewBtn = iconBtn(asList ? "grid" : "list", v -> toggleView());
        moreBtn = iconBtn("more", v -> showMainMenu(v));
        top.addView(searchBtn);
        top.addView(viewBtn);
        top.addView(moreBtn);
        column.addView(top, new LinearLayout.LayoutParams(MATCH, WRAP));

        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setHint("Search this folder");
        searchBox.setHintTextColor(t.muted);
        searchBox.setTextColor(t.text);
        searchBox.setTextSize(15);
        searchBox.setBackground(Ui.solid(t.field(), 16, t.panelBorder()));
        searchBox.setPadding(Ui.dp(16), Ui.dp(10), Ui.dp(16), Ui.dp(10));
        searchBox.setVisibility(View.GONE);
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                query = s.toString().trim().toLowerCase(Locale.ROOT);
                applyFilter();
            }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(MATCH, WRAP);
        sp.setMargins(0, Ui.dp(8), 0, 0);
        column.addView(searchBox, sp);

        HorizontalScrollView chipScroll = new HorizontalScrollView(this);
        chipScroll.setHorizontalScrollBarEnabled(false);
        chips = new LinearLayout(this);
        chips.setPadding(0, Ui.dp(8), 0, Ui.dp(8));
        chipScroll.addView(chips, new FrameLayout.LayoutParams(WRAP, WRAP));
        column.addView(chipScroll, new LinearLayout.LayoutParams(MATCH, WRAP));

        FrameLayout contentPanel = new FrameLayout(this);
        contentPanel.setBackground(Ui.panel(20));
        contentPanel.setPadding(Ui.dp(4), Ui.dp(6), Ui.dp(4), Ui.dp(6));
        listHost = new FrameLayout(this);
        contentPanel.addView(listHost, new FrameLayout.LayoutParams(MATCH, MATCH));
        emptyText = label("", 15, t.muted, false);
        emptyText.setGravity(Gravity.CENTER);
        emptyText.setVisibility(View.GONE);
        contentPanel.addView(emptyText, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER));
        column.addView(contentPanel, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        statusText = label("", 12, t.muted, false);
        statusText.setPadding(Ui.dp(8), Ui.dp(6), Ui.dp(8), 0);
        column.addView(statusText, new LinearLayout.LayoutParams(MATCH, WRAP));

        listHost.addOnLayoutChangeListener((v, l, tp, r, bt, ol, ot, or, ob) -> {
            if (!asList && gridView != null) {
                int c = cols(r - l);
                if (c != gridView.getNumColumns()) gridView.setNumColumns(c);
            }
        });

        // floating bars
        selBar = new LinearLayout(this);
        selBar.setOrientation(LinearLayout.HORIZONTAL);
        selBar.setGravity(Gravity.CENTER_VERTICAL);
        selBar.setBackground(Ui.bar(24));
        selBar.setElevation(Ui.dp(8));
        selBar.setPadding(Ui.dp(6), Ui.dp(4), Ui.dp(6), Ui.dp(4));
        selBar.setVisibility(View.GONE);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM);
        bp.setMargins(Ui.dp(12), 0, Ui.dp(12), Ui.dp(16));
        root.addView(selBar, bp);

        pasteBar = new LinearLayout(this);
        pasteBar.setOrientation(LinearLayout.HORIZONTAL);
        pasteBar.setGravity(Gravity.CENTER_VERTICAL);
        pasteBar.setBackground(Ui.bar(24));
        pasteBar.setElevation(Ui.dp(8));
        pasteBar.setPadding(Ui.dp(18), Ui.dp(4), Ui.dp(6), Ui.dp(4));
        pasteBar.setVisibility(View.GONE);
        pasteText = label("", 14.5f, t.text, false);
        pasteBar.addView(pasteText, new LinearLayout.LayoutParams(0, WRAP, 1f));
        TextView pasteBtn = label("Paste here", 14, Color.WHITE, true);
        pasteBtn.setBackground(Ui.accent(18, 235));
        pasteBtn.setPadding(Ui.dp(16), Ui.dp(9), Ui.dp(16), Ui.dp(9));
        pasteBtn.setOnClickListener(v -> paste());
        pasteBar.addView(pasteBtn);
        pasteBar.addView(iconBtn("close", v -> { clip.clear(); updateSelBar(); }));
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM);
        pp.setMargins(Ui.dp(12), 0, Ui.dp(12), Ui.dp(16));
        root.addView(pasteBar, pp);

        setContentView(root);
        getWindow().setStatusBarColor(t.bg1);
        getWindow().setNavigationBarColor(t.bg2);
        WindowInsetsController wc = getWindow().getInsetsController();
        if (wc != null) {
            int light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
            wc.setSystemBarsAppearance(t.dark ? 0 : light, light);
        }
    }

    private void showPermission() {
        column.setVisibility(View.GONE);
        Palette.Theme t = Ui.t;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(Ui.dp(32), Ui.dp(32), Ui.dp(32), Ui.dp(32));
        View pic = new View(this) {
            @Override protected void onDraw(Canvas c) { Icons.folder(c, 0, 0, getWidth(), getHeight(), Ui.t); }
        };
        box.addView(pic, new LinearLayout.LayoutParams(Ui.dp(96), Ui.dp(96)));
        TextView title = label("Allow access to your files", 21, t.text, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, Ui.dp(20), 0, Ui.dp(10));
        box.addView(title);
        TextView body = label("Mellow is a file manager, so Android needs you to switch on “All files access” for it. "
                + "Tap the button, then turn Mellow on and come back.", 15, t.muted, false);
        body.setGravity(Gravity.CENTER);
        box.addView(body);
        TextView btn = label("Open settings", 16, Color.WHITE, true);
        btn.setBackground(Ui.accent(22, 235));
        btn.setPadding(Ui.dp(28), Ui.dp(12), Ui.dp(28), Ui.dp(12));
        btn.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName())));
            } catch (ActivityNotFoundException e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        });
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(WRAP, WRAP);
        bl.topMargin = Ui.dp(28);
        box.addView(btn, bl);
        permView = box;
        root.addView(box, new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    private int cols(int widthPx) {
        int cell = Ui.dp(zoomDp) + Ui.dp(36);
        return Math.max(2, widthPx / Math.max(1, cell));
    }

    private void setupList() {
        listHost.removeAllViews();
        adapter = new FileAdapter(this, selected, asList, Ui.dp(zoomDp));
        adapter.selMode = !selected.isEmpty();
        AbsListView lv;
        gridView = null;
        if (asList) {
            ListView l = new ListView(this);
            l.setDivider(null);
            l.setDividerHeight(0);
            l.setAdapter(adapter);
            lv = l;
        } else {
            GridView g = new GridView(this);
            int w = listHost.getWidth() > 0 ? listHost.getWidth() : getResources().getDisplayMetrics().widthPixels - Ui.dp(32);
            g.setNumColumns(cols(w));
            g.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
            g.setHorizontalSpacing(0);
            g.setVerticalSpacing(0);
            g.setAdapter(adapter);
            gridView = g;
            lv = g;
        }
        lv.setSelector(new ColorDrawable(Color.TRANSPARENT));
        lv.setFastScrollEnabled(true);
        lv.setClipToPadding(false);
        lv.setPadding(0, 0, 0, Ui.dp(84));
        lv.setOnItemClickListener((p, v, pos, id) -> onItemTap(pos));
        lv.setOnItemLongClickListener((p, v, pos, id) -> { onItemLong(pos); return true; });
        listHost.addView(lv, new FrameLayout.LayoutParams(MATCH, MATCH));
        listWidget = lv;
        adapter.setItems(shown);
    }

    private void toggleView() {
        asList = !asList;
        prefs.edit().putBoolean("asList", asList).apply();
        viewBtn.setKind(asList ? "grid" : "list");
        setupList();
    }

    private void toggleSearch() {
        if (searchBox.getVisibility() == View.VISIBLE) { closeSearch(); return; }
        searchBox.setVisibility(View.VISIBLE);
        searchBtn.setOn(true);
        searchBox.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(searchBox, 0);
    }

    private void closeSearch() {
        searchBox.setText("");
        searchBox.setVisibility(View.GONE);
        searchBtn.setOn(false);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
    }

    // ---- navigation / listing ---------------------------------------------------------------
    private void openDir(File d) {
        if (d == null) return;
        if (!d.isDirectory()) { toast("That folder isn't available"); return; }
        mode = M_DIR;
        cwd = d;
        lastDir = d;
        selected.clear();
        if (searchBox.getVisibility() == View.VISIBLE) closeSearch();
        query = "";
        scrollTop = true;
        prefs.edit().putString("last", d.getAbsolutePath()).apply();
        updateCrumbs();
        updateSelBar();
        reload();
    }

    private void openTrash() {
        mode = M_TRASH;
        selected.clear();
        if (searchBox.getVisibility() == View.VISIBLE) closeSearch();
        query = "";
        scrollTop = true;
        updateCrumbs();
        updateSelBar();
        reload();
    }

    private void openHidden() {
        if (!started) return;
        mode = M_HIDDEN;
        selected.clear();
        if (searchBox.getVisibility() == View.VISIBLE) closeSearch();
        query = "";
        scrollTop = true;
        updateCrumbs();
        updateSelBar();
        reload();
    }

    private boolean canGoUp() {
        if (mode != M_DIR) return true;
        File parent = cwd == null ? null : cwd.getParentFile();
        return parent != null && Trash.volumeOf(parent, roots) != null;
    }

    private void goUp() {
        if (mode != M_DIR) {
            openDir(lastDir != null && lastDir.isDirectory() ? lastDir : primary);
            return;
        }
        if (canGoUp()) openDir(cwd.getParentFile());
    }

    private void reload() {
        final int ver = ++version;
        final int m = mode;
        final File dir = cwd;
        final boolean dot = showDot;
        final int key = sortKey;
        final boolean desc = sortDesc;
        final List<File> rs = new ArrayList<>(roots);
        final Hidden hs = hiddenStore;
        statusText.setText("Loading...");
        lister.execute(() -> {
            List<Entry> res = new ArrayList<>();
            boolean err = false;
            try {
                if (m == M_TRASH) res = Trash.list(rs);
                else if (m == M_HIDDEN) res = hs.items();
                else res = FileOps.list(dir, dot);
            } catch (Exception e) {
                err = true;
            }
            FileOps.sort(res, key, desc);
            final List<Entry> out = res;
            final boolean failed = err;
            ui.post(() -> {
                if (ver != version) return;
                all = out;
                loadError = failed;
                applyFilter();
            });
        });
    }

    private void applyFilter() {
        List<Entry> l = new ArrayList<>();
        for (Entry e : all) {
            if (query.isEmpty() || e.name.toLowerCase(Locale.ROOT).contains(query)) l.add(e);
        }
        shown = l;
        if (adapter != null) adapter.setItems(shown);
        if (scrollTop && listWidget != null) { listWidget.setSelection(0); scrollTop = false; }
        if (shown.isEmpty()) {
            emptyText.setText(loadError ? "Can't read this folder"
                    : !query.isEmpty() ? "No matches"
                    : mode == M_TRASH ? "Trash is empty"
                    : mode == M_HIDDEN ? "Nothing hidden"
                    : "Empty folder");
            emptyText.setVisibility(View.VISIBLE);
        } else {
            emptyText.setVisibility(View.GONE);
        }
        updateStatus();
    }

    private void updateStatus() {
        if (loadError) { statusText.setText("Can't read this folder"); return; }
        int n = shown.size();
        String s = n + (n == 1 ? " item" : " items");
        if (!selected.isEmpty()) {
            long sz = 0;
            for (Entry e : shown) if (selected.contains(e.path()) && !e.dir) sz += e.size;
            s = selected.size() + " selected" + (sz > 0 ? "  ·  " + FileOps.humanSize(sz) : "") + "  of  " + s;
        }
        statusText.setText(s);
    }

    private File volumeOf(File f) { return Trash.volumeOf(f, roots); }

    private void updateCrumbs() {
        crumbs.removeAllViews();
        final List<String> labels = new ArrayList<>();
        final List<File> targets = new ArrayList<>();
        if (mode == M_TRASH) { labels.add("Trash"); targets.add(null); }
        else if (mode == M_HIDDEN) { labels.add("Hidden"); targets.add(null); }
        else if (cwd != null) {
            File vol = volumeOf(cwd);
            int vi = vol == null ? -1 : roots.indexOf(vol);
            labels.add(vi >= 0 ? rootNames.get(vi) : "Storage");
            targets.add(vol);
            if (vol != null) {
                String rel = cwd.getAbsolutePath().substring(vol.getAbsolutePath().length());
                File acc = vol;
                for (String part : rel.split("/")) {
                    if (part.isEmpty()) continue;
                    acc = new File(acc, part);
                    labels.add(part);
                    targets.add(acc);
                }
            }
        }
        Palette.Theme t = Ui.t;
        for (int i = 0; i < labels.size(); i++) {
            final int idx = i;
            boolean last = i == labels.size() - 1;
            if (i > 0) {
                TextView sep = label("›", 16, t.muted, false);
                sep.setPadding(Ui.dp(2), 0, Ui.dp(2), 0);
                crumbs.addView(sep);
            }
            TextView tv = label(labels.get(i), 14.5f, last ? t.text : t.muted, last);
            tv.setPadding(Ui.dp(10), Ui.dp(6), Ui.dp(10), Ui.dp(6));
            tv.setSingleLine(true);
            if (last) tv.setBackground(Ui.accent(12, 60));
            tv.setOnClickListener(v -> {
                File target = targets.get(idx);
                if (target != null && idx < labels.size() - 1) openDir(target);
            });
            tv.setOnLongClickListener(v -> { openHidden(); return true; });
            crumbs.addView(tv);
        }
        crumbScroll.post(() -> crumbScroll.fullScroll(View.FOCUS_RIGHT));
        upBtn.setEnabled(canGoUp());
        rebuildChips();
    }

    private void rebuildChips() {
        chips.removeAllViews();
        if (primary == null) return;
        addChip("Internal storage", primary, false);
        String[][] common = {{"Download", "Downloads"}, {"DCIM", "Camera"}, {"Pictures", "Pictures"},
                {"Documents", "Documents"}, {"Music", "Music"}, {"Movies", "Movies"}};
        for (String[] c : common) {
            File f = new File(primary, c[0]);
            if (f.isDirectory()) addChip(c[1], f, false);
        }
        for (int i = 0; i < roots.size(); i++) {
            if (!roots.get(i).equals(primary)) addChip(rootNames.get(i), roots.get(i), false);
        }
        addChip("Trash", null, true);
    }

    private void addChip(String text, final File dir, final boolean trash) {
        Palette.Theme t = Ui.t;
        boolean on = trash ? mode == M_TRASH : (mode == M_DIR && cwd != null && dir.equals(cwd));
        TextView tv = label(text, 13.5f, t.text, on);
        tv.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
        tv.setBackground(on ? Ui.accent(18, 110) : Ui.solid(t.field(), 18, t.panelBorder()));
        tv.setOnClickListener(v -> { if (trash) openTrash(); else openDir(dir); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
        lp.setMargins(0, 0, Ui.dp(8), 0);
        chips.addView(tv, lp);
    }

    // ---- taps / selection -------------------------------------------------------------------------
    private void onItemTap(int pos) {
        if (pos < 0 || pos >= shown.size()) return;
        Entry e = shown.get(pos);
        if (!selected.isEmpty()) { toggleSelect(e); return; }
        if (e.dir) {
            if (mode == M_TRASH) { toast("Restore it first to open it"); return; }
            openDir(e.file);
        } else {
            if (mode == M_TRASH) { toast("Restore it first to open it"); return; }
            openFile(e);
        }
    }

    private void onItemLong(int pos) {
        if (pos < 0 || pos >= shown.size()) return;
        toggleSelect(shown.get(pos));
    }

    private void toggleSelect(Entry e) {
        String p = e.path();
        if (!selected.remove(p)) selected.add(p);
        updateSelBar();
    }

    private void clearSelection() {
        selected.clear();
        updateSelBar();
    }

    private void updateSelBar() {
        boolean sel = !selected.isEmpty();
        if (adapter != null) adapter.selMode = sel;
        if (sel) rebuildSelBar();
        selBar.setVisibility(sel ? View.VISIBLE : View.GONE);
        boolean showPaste = !sel && !clip.isEmpty() && mode == M_DIR;
        if (showPaste) pasteText.setText((clipCut ? "Move " : "Copy ") + clip.size() + (clip.size() == 1 ? " item here?" : " items here?"));
        pasteBar.setVisibility(showPaste ? View.VISIBLE : View.GONE);
        updateStatus();
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void rebuildSelBar() {
        selBar.removeAllViews();
        selBar.addView(iconBtn("close", v -> clearSelection()));
        TextView n = label(selected.size() + " selected", 15, Ui.t.text, true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        lp.setMargins(Ui.dp(6), 0, 0, 0);
        selBar.addView(n, lp);
        if (mode == M_TRASH) {
            selBar.addView(iconBtn("restore", v -> restoreSelected()));
            selBar.addView(iconBtn("trash", v -> confirmDeleteForever()));
        } else if (mode == M_HIDDEN) {
            selBar.addView(iconBtn("show", v -> unhideSelected()));
            selBar.addView(iconBtn("copy", v -> stageClip(false)));
            selBar.addView(iconBtn("trash", v -> trashSelected()));
        } else {
            selBar.addView(iconBtn("copy", v -> stageClip(false)));
            selBar.addView(iconBtn("cut", v -> stageClip(true)));
            selBar.addView(iconBtn("hide", v -> hideSelected()));
            selBar.addView(iconBtn("trash", v -> trashSelected()));
        }
        selBar.addView(iconBtn("more", v -> showSelMenu(v)));
    }

    private List<File> selectedFiles() {
        List<File> l = new ArrayList<>();
        for (String p : selected) l.add(new File(p));
        return l;
    }

    private void showSelMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu m = pm.getMenu();
        m.add(0, 1, 0, "Select all");
        if (mode == M_DIR && selected.size() == 1) m.add(0, 2, 0, "Rename");
        if (mode != M_TRASH) m.add(0, 3, 0, "Share");
        if (mode != M_TRASH) m.add(0, 4, 0, "Delete permanently");
        pm.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1:
                    for (Entry e : shown) selected.add(e.path());
                    updateSelBar();
                    return true;
                case 2: renameSelected(); return true;
                case 3: shareSelected(); return true;
                case 4: confirmDeleteForever(); return true;
                default: return false;
            }
        });
        pm.show();
    }

    private void showMainMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu m = pm.getMenu();
        if (mode == M_DIR) m.add(0, 1, 0, "New folder");
        m.add(0, 2, 0, "Sort by...");
        m.add(0, 3, 0, "Icon size...");
        MenuItem dot = m.add(0, 4, 0, "Show dot-files");
        dot.setCheckable(true);
        dot.setChecked(showDot);
        m.add(0, 5, 0, "Appearance...");
        if (mode == M_TRASH) m.add(0, 6, 0, "Empty trash");
        m.add(0, 7, 0, "Refresh");
        pm.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1: newFolder(); return true;
                case 2: sortDialog(); return true;
                case 3: sizeDialog(); return true;
                case 4:
                    showDot = !showDot;
                    prefs.edit().putBoolean("showDot", showDot).apply();
                    reload();
                    return true;
                case 5: appearanceDialog(); return true;
                case 6: confirmEmptyTrash(); return true;
                case 7: reload(); return true;
                default: return false;
            }
        });
        pm.show();
    }

    // ---- actions ---------------------------------------------------------------------------------------
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private void runOp(final String busy, final Callable<String> job) {
        statusText.setText(busy);
        worker.execute(() -> {
            String msg;
            try { msg = job.call(); } catch (Exception e) { msg = "Failed: " + e.getMessage(); }
            final String m = msg;
            ui.post(() -> { toast(m); clearSelection(); reload(); });
        });
    }

    private FileOps.Progress progress(final String busy) {
        return new FileOps.Progress() {
            long done, last;
            @Override public void add(long n) {
                done += n;
                long now = SystemClock.uptimeMillis();
                if (now - last > 250) {
                    last = now;
                    final long d = done;
                    ui.post(() -> statusText.setText(busy + "  " + FileOps.humanSize(d)));
                }
            }
        };
    }

    private void stageClip(boolean cut) {
        clip.clear();
        clip.addAll(selectedFiles());
        clipCut = cut;
        toast((cut ? "Cut " : "Copied ") + clip.size() + (clip.size() == 1 ? " item" : " items") + " - open a folder and tap Paste");
        clearSelection();
    }

    private void paste() {
        if (mode != M_DIR || cwd == null || clip.isEmpty()) return;
        final List<File> srcs = new ArrayList<>(clip);
        final boolean cut = clipCut;
        final File dest = cwd;
        if (cut) clip.clear();
        updateSelBar();
        final String busy = cut ? "Moving..." : "Copying...";
        final FileOps.Progress pr = progress(busy);
        runOp(busy, () -> FileOps.paste(srcs, dest, cut, pr).summary(cut ? "Moved" : "Copied"));
    }

    private void trashSelected() {
        final List<File> files = selectedFiles();
        final List<File> rs = new ArrayList<>(roots);
        runOp("Moving to trash...", () -> {
            int ok = 0;
            String err = null;
            for (File f : files) {
                try { Trash.moveToTrash(f, rs); ok++; } catch (IOException e) { err = e.getMessage(); }
            }
            return "Moved " + ok + " to trash" + (err != null ? " - " + err : "");
        });
    }

    private void restoreSelected() {
        final List<File> files = selectedFiles();
        runOp("Restoring...", () -> {
            int ok = 0;
            String err = null;
            for (File f : files) {
                try { Trash.restore(f); ok++; } catch (IOException e) { err = e.getMessage(); }
            }
            return "Restored " + ok + " item" + (ok == 1 ? "" : "s") + (err != null ? " - " + err : "");
        });
    }

    private void confirmDeleteForever() {
        final List<File> files = selectedFiles();
        if (files.isEmpty()) return;
        final boolean inTrash = mode == M_TRASH;
        String what = files.size() == 1 ? "\"" + files.get(0).getName() + "\"" : files.size() + " items";
        new AlertDialog.Builder(this)
                .setTitle("Delete permanently?")
                .setMessage(what + " will be gone for good. This can't be undone.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, w) -> runOp("Deleting...", () -> {
                    int ok = 0;
                    for (File f : files) {
                        boolean done = inTrash ? Trash.purge(f) : FileOps.deleteRecursive(f);
                        if (done) ok++;
                    }
                    return "Deleted " + ok + " of " + files.size();
                }))
                .show();
    }

    private void confirmEmptyTrash() {
        final List<File> rs = new ArrayList<>(roots);
        new AlertDialog.Builder(this)
                .setTitle("Empty trash?")
                .setMessage("Everything in the trash will be deleted permanently.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Empty", (d, w) -> runOp("Emptying trash...", () -> "Deleted " + Trash.emptyAll(rs) + " items"))
                .show();
    }

    private void hideSelected() {
        final List<File> files = selectedFiles();
        final Hidden hs = hiddenStore;
        runOp("Hiding...", () -> {
            FileOps.Result r = hs.hide(files);
            String msg = r.summary("Hidden");
            if (r.ok > 0 && !prefs.getBoolean("hintVault", false)) {
                prefs.edit().putBoolean("hintVault", true).apply();
                msg += "  -  to see them again, long-press the path bar";
            }
            return msg;
        });
    }

    private void unhideSelected() {
        final List<File> files = selectedFiles();
        final Hidden hs = hiddenStore;
        runOp("Unhiding...", () -> hs.unhide(files).summary("Unhid"));
    }

    private void renameSelected() {
        if (selected.size() != 1 || mode != M_DIR) return;
        final File f = new File(selected.iterator().next());
        promptText("Rename", f.getName(), name -> {
            if (name.isEmpty() || name.contains("/") || name.equals(f.getName())) return;
            File to = new File(f.getParentFile(), name);
            if (FileOps.exists(to)) { toast("That name already exists"); return; }
            if (f.renameTo(to)) { toast("Renamed"); clearSelection(); reload(); } else toast("Could not rename");
        });
    }

    private void newFolder() {
        if (mode != M_DIR || cwd == null) return;
        promptText("New folder", "New folder", name -> {
            if (name.isEmpty() || name.contains("/")) return;
            File d = new File(cwd, name);
            if (FileOps.exists(d)) { toast("That name already exists"); return; }
            if (d.mkdir()) { toast("Folder created"); reload(); } else toast("Could not create the folder");
        });
    }

    private void shareSelected() {
        ArrayList<Uri> uris = new ArrayList<>();
        String firstName = "";
        for (String p : selected) {
            File f = new File(p);
            if (f.isFile()) { if (uris.isEmpty()) firstName = f.getName(); uris.add(FileShareProvider.uriFor(f)); }
        }
        if (uris.isEmpty()) { toast("Select files to share (folders can't be shared)"); return; }
        Intent i;
        if (uris.size() == 1) {
            i = new Intent(Intent.ACTION_SEND);
            i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
            i.setType(FileShareProvider.mimeOf(firstName));
        } else {
            i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            i.setType("*/*");
        }
        ClipData cd = ClipData.newRawUri("files", uris.get(0));
        for (int k = 1; k < uris.size(); k++) cd.addItem(new ClipData.Item(uris.get(k)));
        i.setClipData(cd);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(i, "Share")); } catch (ActivityNotFoundException e) { toast("Nothing to share with"); }
    }

    private void openFile(Entry e) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(FileShareProvider.uriFor(e.file), FileShareProvider.mimeOf(e.name));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(i); } catch (ActivityNotFoundException ex) { toast("No app found to open this file"); }
    }

    // ---- dialogs -------------------------------------------------------------------------------------------
    private void promptText(String title, String initial, final TextCb cb) {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(initial);
        int dot = initial.lastIndexOf('.');
        et.setSelection(0, dot > 0 ? dot : initial.length());
        FrameLayout box = new FrameLayout(this);
        box.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(20), 0);
        box.addView(et, new FrameLayout.LayoutParams(MATCH, WRAP));
        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("OK", (d, w) -> cb.got(et.getText().toString().trim()))
                .create();
        dlg.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        dlg.show();
    }

    private void saveSort() {
        prefs.edit().putInt("sortKey", sortKey).putBoolean("sortDesc", sortDesc).apply();
        reload();
    }

    private void sortDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(24), Ui.dp(8), Ui.dp(24), 0);
        final RadioGroup rg = new RadioGroup(this);
        String[] names = {"Name", "Size", "Type", "Modified"};
        for (int i = 0; i < names.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(names[i]);
            rb.setId(100 + i);
            rg.addView(rb);
        }
        rg.check(100 + sortKey);
        final CheckBox desc = new CheckBox(this);
        desc.setText("Reverse order");
        desc.setChecked(sortDesc);
        rg.setOnCheckedChangeListener((g, id) -> {
            int k = id - 100;
            if (k != sortKey) {
                sortKey = k;
                sortDesc = k == FileOps.SORT_SIZE || k == FileOps.SORT_DATE;
                desc.setChecked(sortDesc);
                saveSort();
            }
        });
        desc.setOnCheckedChangeListener((b, on) -> {
            if (on != sortDesc) { sortDesc = on; saveSort(); }
        });
        box.addView(rg);
        box.addView(desc);
        new AlertDialog.Builder(this).setTitle("Sort by").setView(box).setPositiveButton("Done", null).show();
    }

    private void sizeDialog() {
        final int[] dps = {44, 56, 72};
        int cur = zoomDp <= 48 ? 0 : zoomDp <= 60 ? 1 : 2;
        new AlertDialog.Builder(this)
                .setTitle("Icon size")
                .setSingleChoiceItems(new String[]{"Small", "Medium", "Large"}, cur, (d, which) -> {
                    zoomDp = dps[which];
                    prefs.edit().putInt("zoomDp", zoomDp).apply();
                    setupList();
                    d.dismiss();
                })
                .show();
    }

    private static final class Swatch extends View {
        private int c1, c2;
        private final boolean on;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Swatch(Context c, int c1, int c2, boolean on) {
            super(c);
            this.c1 = c1;
            this.c2 = c2;
            this.on = on;
        }

        void setColors(int a, int b) { c1 = a; c2 = b; invalidate(); }

        @Override protected void onMeasure(int w, int h) {
            int s = Ui.dp(44);
            setMeasuredDimension(s, s);
        }

        @Override protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, r = Ui.dp(15);
            p.setStyle(Paint.Style.FILL);
            p.setShader(new android.graphics.LinearGradient(cx - r, cy - r, cx + r, cy + r, c1, c2, android.graphics.Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, p);
            p.setShader(null);
            if (on) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(Ui.dp(2));
                p.setColor(0xFF9A9A9A);
                c.drawCircle(cx, cy, r + Ui.dp(4), p);
            }
        }
    }

    private void appearanceDialog() {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), Ui.dp(8));
        sv.addView(box);

        box.addView(sectionLabel("Palette"));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        String current = prefs.getString("palette", "Dusk");
        for (final String nm : Palette.NAMES) {
            Palette.Theme th = Palette.named(nm, 1f);
            Swatch s = new Swatch(this, th.a1, th.a2, nm.equals(current));
            s.setOnClickListener(v -> {
                prefs.edit().putString("palette", nm).apply();
                recreate();
            });
            row.addView(s);
        }
        hs.addView(row);
        box.addView(hs);

        box.addView(sectionLabel("Colour intensity"));
        RadioGroup rg = new RadioGroup(this);
        rg.setOrientation(RadioGroup.HORIZONTAL);
        String[] names = {"Soft", "Balanced", "Vivid"};
        for (int i = 0; i < names.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(names[i]);
            rb.setId(200 + i);
            rg.addView(rb);
        }
        rg.check(200 + Math.max(0, Math.min(2, prefs.getInt("vibe", 1))));
        rg.setOnCheckedChangeListener((g, id) -> {
            if (prefs.getInt("vibe", 1) != id - 200) {
                prefs.edit().putInt("vibe", id - 200).apply();
                recreate();
            }
        });
        box.addView(rg);

        box.addView(sectionLabel("Any colour"));
        float[] hsl = Palette.toHsl(prefs.getInt("customAccent", 0xFF8f9be0));
        final boolean[] dark = {prefs.getBoolean("customDark", true)};
        final Swatch preview = new Swatch(this, 0, 0, false);
        final SeekBar hue = new SeekBar(this);
        hue.setMax(359);
        hue.setProgress(Math.round(hsl[0] * 359f));
        final SeekBar soft = new SeekBar(this);
        soft.setMax(65);
        soft.setProgress(Math.max(0, Math.min(65, Math.round(hsl[1] * 100f) - 25)));
        final CheckBox darkBox = new CheckBox(this);
        darkBox.setText("Dark background");
        darkBox.setChecked(dark[0]);
        final Runnable upd = () -> {
            float h = hue.getProgress() / 359f;
            float s = (soft.getProgress() + 25) / 100f;
            float l = darkBox.isChecked() ? 0.68f : 0.55f;
            preview.setColors(Palette.hsl(h, s, l), Palette.hsl(h + 0.08f, s, l));
        };
        SeekBar.OnSeekBarChangeListener sl = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int p, boolean u) { upd.run(); }
            @Override public void onStartTrackingTouch(SeekBar b) { }
            @Override public void onStopTrackingTouch(SeekBar b) { }
        };
        hue.setOnSeekBarChangeListener(sl);
        soft.setOnSeekBarChangeListener(sl);
        darkBox.setOnCheckedChangeListener((b, on) -> upd.run());
        upd.run();
        LinearLayout pr = new LinearLayout(this);
        pr.setGravity(Gravity.CENTER_VERTICAL);
        pr.addView(preview);
        TextView hint = label("Hue and softness", 13, Ui.t.muted, false);
        hint.setPadding(Ui.dp(10), 0, 0, 0);
        pr.addView(hint);
        box.addView(pr);
        box.addView(hue);
        box.addView(soft);
        box.addView(darkBox);
        TextView apply = label("Use this colour", 15, Color.WHITE, true);
        apply.setBackground(Ui.accent(20, 235));
        apply.setPadding(Ui.dp(22), Ui.dp(10), Ui.dp(22), Ui.dp(10));
        apply.setOnClickListener(v -> {
            float h = hue.getProgress() / 359f;
            float s = (soft.getProgress() + 25) / 100f;
            float l = darkBox.isChecked() ? 0.68f : 0.55f;
            prefs.edit().putString("palette", "Custom").putInt("customAccent", Palette.hsl(h, s, l))
                    .putBoolean("customDark", darkBox.isChecked()).apply();
            recreate();
        });
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(WRAP, WRAP);
        al.topMargin = Ui.dp(10);
        box.addView(apply, al);

        new AlertDialog.Builder(this).setTitle("Appearance").setView(sv).setPositiveButton("Close", null).show();
    }

    private TextView sectionLabel(String s) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(13);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(0, Ui.dp(16), 0, Ui.dp(6));
        return tv;
    }
}

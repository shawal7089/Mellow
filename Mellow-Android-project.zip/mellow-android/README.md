# Mellow for Android
Soft, glassy file manager. Pixel 7 / GrapheneOS, Android 11+.
Build: push to GitHub (Actions builds Mellow.apk) or run ./build-apk.sh.
First launch: grant "All files access". Hidden vault: long-press any breadcrumb.
